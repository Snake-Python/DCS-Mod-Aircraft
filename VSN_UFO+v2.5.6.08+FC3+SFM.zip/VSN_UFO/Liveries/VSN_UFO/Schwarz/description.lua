livery = {
    {"UFO_1-1", 0, "UFO_Schwarz",true},
	{"UFO_1-2", 0, "UFO_Schwarz",true},
	{"UFO_1-1", ROUGHNESS_METALLIC, "UFO_Nichtmetall_RoughMet",true},
	{"UFO_1-2", ROUGHNESS_METALLIC, "UFO_Nichtmetall_RoughMet",true},
	
	{"UFO_2-1", ROUGHNESS_METALLIC, "UFO_Boden_RoughMet",true},
	{"UFO_2-2", ROUGHNESS_METALLIC, "UFO_Boden_RoughMet",true},
	{"UFO_3-1", ROUGHNESS_METALLIC, "UFO_innen_RoughMet",true},
	{"UFO_3-2", ROUGHNESS_METALLIC, "UFO_innen_RoughMet",true},
	
	--{"UFO_2-1", 0, "UFO_Boden",true},
	--{"UFO_2-2", 0, "UFO_Boden",true},
	--{"UFO_3-1", 0, "UFO_innen",true},
	--{"UFO_3-2", 0, "UFO_innen",true},
	--{"UFO_Leder", 0, "UFO_Leder",true},
	--{"UFO_Alien", 0, "UFO_Alien",true},
	--{"UFO_display_mult", 0, "UFO_Cockpit",true},
	--{"UFO_display_mult_L", 0, "UFO_Cockpit",true},
	--{"UFO_Bano_BL", 0, "UFO_Blau",true},
	--{"UFO_Bano_BB", 0, "UFO_Blau",true},
	--{"UFO_Bano_GL", 0, "UFO_Gelb",true},
	--{"UFO_Bano_GB", 0, "UFO_Gelb",true},
	--{"UFO_Bano_WB", 0, "UFO_Weiss",true},
			
}
name = "Schwarz"
-- by cdpkobra