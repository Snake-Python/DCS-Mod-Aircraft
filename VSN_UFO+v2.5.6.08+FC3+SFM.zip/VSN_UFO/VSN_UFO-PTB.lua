
declare_loadout({
		category	  =  CAT_FUEL_TANKS,
		CLSID         =  "{VSN_UFO_PTB}",
		attribute	  =  {wsType_Air,wsType_Free_Fall,wsType_FuelTank,WSTYPE_PLACEHOLDER},
		Picture       =  "PTB.png",
		displayName   = _("VSN_UFO Zusatztank 5000 Liter"),		
		Weight_Empty  = 5,
		Weight        = 5.0 + 5000 * 0.802,-- = 70 +  3.028 * 200,-- GALLON_TO_KG = 3.785 * 0.8
		Cx_pil		  = 0.000003848,
		shape_table_data = 
		{
			{
	           name     = "VSN_UFO_PTB",
			   file     = "VSN_UFO_PTB";
			   life     = 1;
			   fire     = { 0, 1};
			   username = "VSN_UFO_PTB";
			   index    = WSTYPE_PLACEHOLDER;
			 },
		},	   
	    Elements   =
	    {
			 {
			    Position  =	{0, 0, 0},
	            ShapeName = "VSN_UFO_PTB",
			}, 
		}, 
})

declare_loadout({
		category	  =  CAT_FUEL_TANKS,
		CLSID         =  "{VSN_UFO2_PTB}",
		attribute	  =  {wsType_Air,wsType_Free_Fall,wsType_FuelTank,WSTYPE_PLACEHOLDER},
		Picture       =  "PTB.png",
		displayName   = _("VSN_UFO Zusatztank 10000 Liter"),		
		Weight_Empty  = 5,
		Weight        = 5.0 + 10000 * 0.802,-- = 70 +  3.028 * 200,-- GALLON_TO_KG = 3.785 * 0.8
		Cx_pil		  = 0.000003848,
		shape_table_data = 
		{
			{
	           name     = "VSN_UFO2_PTB",
			   file     = "VSN_UFO2_PTB";
			   life     = 1;
			   fire     = { 0, 1};
			   username = "VSN_UFO2_PTB";
			   index    = WSTYPE_PLACEHOLDER;
			 },
		},	   
	    Elements   =
	    {
			 {
			    Position  =	{0, 0, 0},
	            ShapeName = "VSN_UFO2_PTB",
			}, 
		}, 
})
