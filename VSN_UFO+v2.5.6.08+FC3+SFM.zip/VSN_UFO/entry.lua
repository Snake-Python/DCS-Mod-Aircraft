declare_plugin("VSN_UFO",
{
image     	 = "FC3.bmp",
installed 	 = true, -- if false that will be place holder , or advertising
dirName	  	 = current_mod_path,
displayName  = _("VSN_UFO"),
developerName = _("VSN"),

fileMenuName = _("VSN_UFO"),
update_id        = "VSN_UFO",

version		 = "2.5.6",
state		 = "installed",
info		 = _("VSN_UFO Mod, Modell Created by Herminio Nieves @2013 for comercial and non comercial use. just give the apropiate credits! non movabable parts.."),

Skins	=
	{
		{
		    name	= _("VSN_UFO"),
			dir		= "Theme"
		},
	},
Missions =
	{
		{
			name		    = _("VSN_UFO"),
			dir			    = "Missions",
  		},
	},
LogBook =
	{
		{
			name		= _("VSN_UFO"),
			type		= "VSN_UFO",
		},
	},	
		
InputProfiles =
	{
		["VSN_UFO"] = current_mod_path .. '/Input/VSN_UFO',
	},
binaries 	 =
{

},	
	
})
----------------------------------------------------------------------------------------
mount_vfs_model_path	(current_mod_path.."/Shapes")
mount_vfs_liveries_path (current_mod_path.."/Liveries")
mount_vfs_texture_path  (current_mod_path.."/Textures/VSN_UFO")
-------------------------------------------------------------------------------------
local cfg_path = current_mod_path ..  "/FM/config.lua"
dofile(cfg_path)
F15FM.old 				= 6
dofile(current_mod_path.."/Views-UFO_Pit.lua")
make_view_settings('VSN_UFO', ViewSettings, SnapViews)
make_flyable('VSN_UFO',current_mod_path..'/Cockpit/KneeboardRight/',F15FM, current_mod_path..'/Comm.lua')--AFM
-------------------------------------------------------------------------------------
dofile(current_mod_path..'/VSN_UFO.lua')
dofile(current_mod_path..'/VSN_UFO_Ki.lua')
dofile(current_mod_path..'/VSN_UFO-PTB.lua')
-------------------------------------------------------------------------------------
plugin_done()
