planes = {
    
	{
    name = _('Nevada_UFO'),
    file = 'Nevada_UFO.miz',
    },
	{
    name = _('Nevada_Nacht UFO'),
    file = 'Nevada_Nacht UFO.miz',
    },
	{
    name = _('UFO_Test'),
    file = 'UFO_Test.miz',
    },
	{
    name = _('UFO_Test2'),
    file = 'UFO_Test2.miz',
    },
	{
    name = _('Normandy_UFO'),
    file = 'Normandy_UFO.miz',
    },
	{
    name = _('Normandy-Nacht_UFO'),
    file = 'Normandy-Nacht_UFO.miz',
    },
	{
    name = _('Persian Gulf UFO'),
    file = 'Persian Gulf_UFO.miz',
    },
	{
    name = _('Persian Gulf Nacht UFO'),
    file = 'Persian Gulf-Nacht_UFO.miz',
    },
	
	
	
}