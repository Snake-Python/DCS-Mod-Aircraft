-- BEGIN -- this part of the file is not intended for an end-user editing
--[[ --------------------------------------------------------------- ]]--

VSN_UFO = {
center_of_mass		= {-0.172  ,  -0.6,	   0},--x,y,z
moment_of_inertia 	= {38912  ,254758,223845,-705},--Ix,Iy,Iz,Ixy
suspension 			= {
	  { -- NOSE WHEEL
		  self_attitude     = true,
		  --amortizer_min_length     = 0.0,
		  amortizer_max_length     = 0.55, --amortizer maximale Länge
		  amortizer_basic_length     = 0.55, --amortizer Grundlänge
		  amortizer_spring_force_factor   = 500000.0, --990000.0, --Kraft = Federkraft Faktor * pow (Verringerung der Länge, amortizer Federkraft Faktor Rate
		  amortizer_spring_force_factor_rate  = 2, --amortizer direkten Dämpferkraft Faktor
		  amortizer_static_force     = 10000.0, --47500.0,--amortizer statische Kraft
		  amortizer_reduce_length     = 0.55, --amortizer reduzieren Länge
		  amortizer_direct_damper_force_factor = 10000, --50000, --amortizer direkten Dämpferkraft Faktor
		  amortizer_back_damper_force_factor  = 100000, --60000, --Amortizer Dämpferkraft Faktor zurück

		  anti_skid_installed = false,--Anti-Rutsch installiert

		  wheel_radius      = 0.377,
		  wheel_static_friction_factor  = 0.75 ,--Rad statischen Reibungsfaktor
		  wheel_side_friction_factor    = 0.85 ,--Radseite Reibungsfaktor
		  wheel_roll_friction_factor    = 0.07,--0.08 ,--Rad Rollreibungsfaktor
		  wheel_glide_friction_factor   = 0.65 ,--Rad glide Reibungsfaktor
		  wheel_damage_force_factor     = 450.0,

		  arg_post     = 0,
		  arg_amortizer    = 1,
		  arg_wheel_rotation = 101,
		  arg_wheel_damage   = 134
	  },
	  { -- LEFT WHEEL
		  --amortizer_min_length     = 0.0,
		  amortizer_max_length     = 0.55, 
		  amortizer_basic_length     = 0.55, 
		  amortizer_spring_force_factor   = 10000000.0, --29370398.0,
		  amortizer_spring_force_factor_rate  = 3,
		  amortizer_static_force     = 100000.0, --202394.0, 
		  amortizer_reduce_length     = 0.55, 
		  amortizer_direct_damper_force_factor =  10000, --50000.0,
		  amortizer_back_damper_force_factor   = 100000, --25000.0,

		  anti_skid_installed = true,

		  wheel_radius      = 0.486,
		  wheel_static_friction_factor  = 0.75 ,
		  wheel_side_friction_factor    = 0.85 ,
		  wheel_roll_friction_factor    = 0.07,--0.08 ,--Rad Rollreibungsfaktor
		  wheel_glide_friction_factor   = 0.65 ,
		  wheel_damage_force_factor     = 450.0,
		  wheel_brake_moment_max		= 195000.0,--15000.0,--Bremsmoment max

		  arg_post     = 5,
		  arg_amortizer    = 6,
		  arg_wheel_rotation = 102,
		  arg_wheel_damage   = 136
	  },
	  {  -- RIGHT WHEEL
		  --amortizer_min_length     = 0.0,
		  amortizer_max_length     = 0.55, 
		  amortizer_basic_length     = 0.55,
		  amortizer_spring_force_factor   = 10000000.0, --29370398.0,
		  amortizer_spring_force_factor_rate  = 3,
		  amortizer_static_force     = 100000.0, --202394.0, 
		  amortizer_reduce_length     = 0.55, 
		  amortizer_direct_damper_force_factor =  10000, --50000.0,
		  amortizer_back_damper_force_factor   = 100000, --25000.0,

		  anti_skid_installed = true,

		  wheel_radius      = 0.486,
		  wheel_static_friction_factor  = 0.75 ,
		  wheel_side_friction_factor    = 0.85 ,
		  wheel_roll_friction_factor    = 0.07,--0.08 ,--Rad Rollreibungsfaktor
		  wheel_glide_friction_factor   = 0.65 ,
		  wheel_damage_force_factor     = 450.0,
		  wheel_brake_moment_max		= 195000.0,--15000.0,--Bremsmoment max

		  arg_post     = 3,
		  arg_amortizer    = 4,
		  arg_wheel_rotation = 103,
		  arg_wheel_damage   = 135
	  }
	}, -- gears
	
disable_built_in_oxygen_system	= true,
--[[ ------------------------------------------------------------- ]]--
-- END -- this part of the file is not intended for an end-user editing

-- view shake amplitude
minor_shake_ampl = 0.21,
major_shake_ampl = 0.5,

-- debug
debugLine = "{M}:%1.3f {IAS}:%4.1f {AoA}:%2.1f {ny}:%2.1f {nx}:%1.2f {AoS}:%2.1f {mass}:%2.1f {Fy}:%2.1f {Fx}:%2.1f {wx}:%.1f {wy}:%.1f {wz}:%.1f {Vy}:%2.1f {dPsi}:%2.1f",
record_enabled = false,
}